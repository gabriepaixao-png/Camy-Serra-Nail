/**
 * HeroSection — Camy Serra Nail Studio
 * Design: Full-screen hero com imagem de fundo, overlay cereja escuro, texto centralizado
 * Typography: Playfair Display para título, Dancing Script para subtítulo, DM Sans para corpo
 */
import { useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/hero-bg-g9riZWv69Jo4wEt6gwsNj3.webp";
const CHERRY_DECO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/cherry-red-decoration-4hViVqhjDgSzhKtbFEBVog.webp";

export default function HeroSection() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToNext = () => {
    const el = document.querySelector("#galeria");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${HERO_IMAGE})` }}
      />

      {/* Dark overlay with cherry tint */}
      <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.12_0.08_18/0.75)] via-[oklch(0.18_0.10_18/0.65)] to-[oklch(0.08_0.05_18/0.85)]" />

      {/* Decorative cherry SVG — top right */}
      <div
        className={`absolute top-24 right-8 md:right-16 w-28 md:w-40 opacity-50 cherry-float transition-all duration-1000 ${
          loaded ? "opacity-50 translate-x-0" : "opacity-0 translate-x-8"
        }`}
      >
        <svg viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-lg">
          <circle cx="35" cy="85" r="22" fill="#8B1A1A" opacity="0.9"/>
          <circle cx="35" cy="85" r="22" fill="url(#cherry1)" opacity="0.9"/>
          <circle cx="75" cy="90" r="20" fill="#A01515" opacity="0.9"/>
          <circle cx="75" cy="90" r="20" fill="url(#cherry2)" opacity="0.9"/>
          <path d="M35 63 Q50 30 80 20 Q90 50 75 70" stroke="#2D5016" strokeWidth="3" fill="none" strokeLinecap="round"/>
          <path d="M75 70 Q80 40 95 25" stroke="#2D5016" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
          <ellipse cx="88" cy="22" rx="14" ry="9" fill="#3A6B1A" transform="rotate(-20 88 22)"/>
          <ellipse cx="100" cy="18" rx="12" ry="8" fill="#2D5016" transform="rotate(10 100 18)"/>
          <circle cx="28" cy="78" r="5" fill="white" opacity="0.3"/>
          <circle cx="68" cy="83" r="4" fill="white" opacity="0.3"/>
          <defs>
            <radialGradient id="cherry1" cx="35%" cy="30%" r="60%">
              <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
              <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
            </radialGradient>
            <radialGradient id="cherry2" cx="35%" cy="30%" r="60%">
              <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
              <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
            </radialGradient>
          </defs>
        </svg>
      </div>

      {/* Decorative cherry SVG — bottom left */}
      <div
        className={`absolute bottom-24 left-4 md:left-12 w-20 md:w-28 opacity-35 cherry-float transition-all duration-1000 delay-300 ${
          loaded ? "opacity-35 translate-x-0" : "opacity-0 -translate-x-8"
        }`}
        style={{ animationDelay: "2s" }}
      >
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-lg">
          <circle cx="35" cy="72" r="20" fill="#8B1A1A" opacity="0.9"/>
          <circle cx="35" cy="72" r="20" fill="url(#cherry3)" opacity="0.9"/>
          <circle cx="65" cy="78" r="18" fill="#A01515" opacity="0.9"/>
          <circle cx="65" cy="78" r="18" fill="url(#cherry4)" opacity="0.9"/>
          <path d="M35 52 Q48 25 70 18" stroke="#2D5016" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
          <path d="M65 60 Q72 35 85 22" stroke="#2D5016" strokeWidth="2" fill="none" strokeLinecap="round"/>
          <ellipse cx="78" cy="18" rx="12" ry="8" fill="#3A6B1A" transform="rotate(-15 78 18)"/>
          <circle cx="28" cy="66" r="4" fill="white" opacity="0.3"/>
          <circle cx="58" cy="72" r="3" fill="white" opacity="0.3"/>
          <defs>
            <radialGradient id="cherry3" cx="35%" cy="30%" r="60%">
              <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
              <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
            </radialGradient>
            <radialGradient id="cherry4" cx="35%" cy="30%" r="60%">
              <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
              <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
            </radialGradient>
          </defs>
        </svg>
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        {/* Script accent */}
        <div
          className={`transition-all duration-800 ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <span className="font-script text-[oklch(0.72_0.10_75)] text-2xl md:text-3xl">
            bem-vinda ao
          </span>
        </div>

        {/* Main Title */}
        <h1
          className={`font-display text-5xl md:text-7xl lg:text-8xl font-bold text-white mt-2 mb-4 leading-tight transition-all duration-1000 delay-200 ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          Camy Serra
          <br />
          <span className="italic font-medium text-4xl md:text-5xl lg:text-6xl text-[oklch(0.92_0.03_18)]">
            Nail Studio
          </span>
        </h1>

        {/* Gold divider */}
        <div
          className={`flex items-center justify-center gap-3 my-6 transition-all duration-1000 delay-400 ${
            loaded ? "opacity-100 scale-100" : "opacity-0 scale-75"
          }`}
        >
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-[oklch(0.72_0.10_75)]" />
          <span className="text-[oklch(0.72_0.10_75)] text-lg">✦</span>
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-[oklch(0.72_0.10_75)]" />
        </div>

        {/* Highlight phrase */}
        <div
          className={`transition-all duration-1000 delay-500 ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <p className="font-display text-xl md:text-2xl lg:text-3xl text-[oklch(0.92_0.03_18)] italic font-medium">
            8 anos transformando unhas em arte
          </p>
        </div>

        {/* Subtitle */}
        <p
          className={`font-body text-white/80 text-base md:text-lg mt-4 max-w-xl mx-auto leading-relaxed transition-all duration-1000 delay-600 ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          Nail art exclusiva, alongamentos e cuidados personalizados para realçar a sua beleza com sofisticação.
        </p>

        {/* CTA Buttons */}
        <div
          className={`flex flex-col sm:flex-row items-center justify-center gap-4 mt-10 transition-all duration-1000 delay-700 ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <a
            href="https://wa.me/5500000000000?text=Olá%20Camy!%20Gostaria%20de%20agendar%20um%20horário."
            target="_blank"
            rel="noopener noreferrer"
            className="whatsapp-pulse inline-flex items-center gap-2 bg-[oklch(0.42_0.18_18)] hover:bg-[oklch(0.52_0.20_18)] text-white font-body font-medium px-8 py-4 rounded-full transition-all duration-300 hover:scale-105 shadow-lg"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            Agendar pelo WhatsApp
          </a>
          <a
            href="#servicos"
            onClick={(e) => { e.preventDefault(); document.querySelector("#servicos")?.scrollIntoView({ behavior: "smooth" }); }}
            className="inline-flex items-center gap-2 border border-white/60 text-white font-body font-medium px-8 py-4 rounded-full transition-all duration-300 hover:bg-white/10 hover:border-white"
          >
            Ver Serviços
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollToNext}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60 hover:text-white transition-colors duration-300 animate-bounce"
        aria-label="Rolar para baixo"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
}
