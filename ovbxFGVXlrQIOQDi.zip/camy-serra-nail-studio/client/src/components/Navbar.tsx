/**
 * Navbar — Camy Serra Nail Studio
 * Design: Modern Feminine Luxury — sticky nav com logo elegante e links de navegação
 * Colors: white bg com texto cherry, scroll → cherry deep bg com texto branco
 */
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Início", href: "#inicio" },
  { label: "Galeria", href: "#galeria" },
  { label: "Serviços", href: "#servicos" },
  { label: "Depoimentos", href: "#depoimentos" },
  { label: "Contato", href: "#contato" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[oklch(0.22_0.10_18)] shadow-lg shadow-[oklch(0.22_0.10_18)/30]"
          : "bg-white/90 backdrop-blur-md shadow-sm"
      }`}
    >
      <div className="container mx-auto flex items-center justify-between py-4">
        {/* Logo */}
        <a
          href="#inicio"
          onClick={(e) => { e.preventDefault(); handleNavClick("#inicio"); }}
          className="flex flex-col leading-none"
        >
          <span
            className={`font-script text-2xl transition-colors duration-500 ${
              scrolled ? "text-[oklch(0.72_0.10_75)]" : "text-[oklch(0.42_0.18_18)]"
            }`}
          >
            Camy Serra
          </span>
          <span
            className={`font-body text-[10px] tracking-[0.25em] uppercase transition-colors duration-500 ${
              scrolled ? "text-white/70" : "text-[oklch(0.50_0.05_18)]"
            }`}
          >
            Nail Studio
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
              className={`font-body text-sm tracking-wide transition-all duration-300 hover:opacity-70 ${
                scrolled ? "text-white" : "text-[oklch(0.25_0.08_18)]"
              }`}
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contato"
            onClick={(e) => { e.preventDefault(); handleNavClick("#contato"); }}
            className={`font-body text-sm px-5 py-2 rounded-full border transition-all duration-300 hover:scale-105 ${
              scrolled
                ? "border-[oklch(0.72_0.10_75)] text-[oklch(0.72_0.10_75)] hover:bg-[oklch(0.72_0.10_75)] hover:text-[oklch(0.22_0.10_18)]"
                : "border-[oklch(0.42_0.18_18)] text-[oklch(0.42_0.18_18)] hover:bg-[oklch(0.42_0.18_18)] hover:text-white"
            }`}
          >
            Agendar
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className={`md:hidden p-2 transition-colors duration-300 ${
            scrolled ? "text-white" : "text-[oklch(0.25_0.08_18)]"
          }`}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Menu"
        >
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden transition-all duration-400 overflow-hidden ${
          menuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        } ${scrolled ? "bg-[oklch(0.22_0.10_18)]" : "bg-white"}`}
      >
        <nav className="container mx-auto flex flex-col py-4 gap-1">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
              className={`font-body text-sm py-3 px-2 border-b transition-colors duration-200 ${
                scrolled
                  ? "text-white border-white/10 hover:text-[oklch(0.72_0.10_75)]"
                  : "text-[oklch(0.25_0.08_18)] border-[oklch(0.88_0.03_18)] hover:text-[oklch(0.42_0.18_18)]"
              }`}
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contato"
            onClick={(e) => { e.preventDefault(); handleNavClick("#contato"); }}
            className="mt-3 font-body text-sm px-5 py-3 rounded-full bg-[oklch(0.42_0.18_18)] text-white text-center hover:bg-[oklch(0.32_0.14_18)] transition-colors duration-300"
          >
            Agendar Agora
          </a>
        </nav>
      </div>
    </header>
  );
}
