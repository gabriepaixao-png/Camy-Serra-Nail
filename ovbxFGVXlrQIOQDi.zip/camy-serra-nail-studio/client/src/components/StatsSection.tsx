/**
 * StatsSection — Camy Serra Nail Studio
 * Design: Faixa com fundo cereja com números de destaque
 * Exibe: 8 anos de experiência, clientes atendidas, etc.
 */
import { useEffect, useRef, useState } from "react";

const stats = [
  { value: "8", suffix: "+", label: "Anos de Experiência" },
  { value: "500", suffix: "+", label: "Clientes Satisfeitas" },
  { value: "1000", suffix: "+", label: "Unhas Transformadas" },
  { value: "5", suffix: "★", label: "Avaliação Média" },
];

function CountUp({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true); },
      { threshold: 0.5 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    const duration = 1500;
    const steps = 40;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [started, target]);

  return (
    <span ref={ref}>
      {count}{suffix}
    </span>
  );
}

export default function StatsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-16 bg-[oklch(0.42_0.18_18)]">
      <div
        ref={ref}
        className={`container mx-auto transition-all duration-700 ${
          visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className="transition-all duration-700"
              style={{ transitionDelay: `${i * 150}ms` }}
            >
              <div className="font-display text-4xl md:text-5xl font-bold text-white mb-2">
                <CountUp
                  target={parseInt(stat.value)}
                  suffix={stat.suffix}
                />
              </div>
              <div className="font-body text-white/70 text-sm tracking-wide">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
