/**
 * AboutSection — Camy Serra Nail Studio
 * Design: Seção sobre com destaque dos 8 anos, imagem lateral e texto elegante
 * Layout: Duas colunas assimétricas — imagem à esquerda, texto à direita
 */
import { useEffect, useRef, useState } from "react";
import { CheckCircle2 } from "lucide-react";

const GALLERY_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/gallery-5-mPujJmiYQ2Mmn9hSpvMAkE.webp";
// Cherry SVG usado inline

const highlights = [
  "Técnicas exclusivas de nail art",
  "Produtos de alta qualidade importados",
  "Atendimento personalizado e acolhedor",
  "Studio higienizado e climatizado",
];

export default function AboutSection() {
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const [leftVisible, setLeftVisible] = useState(false);
  const [rightVisible, setRightVisible] = useState(false);

  useEffect(() => {
    const observers: IntersectionObserver[] = [];

    const leftEl = leftRef.current;
    if (leftEl) {
      const obs = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) setLeftVisible(true); },
        { threshold: 0.2 }
      );
      obs.observe(leftEl);
      observers.push(obs);
    }

    const rightEl = rightRef.current;
    if (rightEl) {
      const obs = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) setRightVisible(true); },
        { threshold: 0.2 }
      );
      obs.observe(rightEl);
      observers.push(obs);
    }

    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left — Image with decorative elements */}
          <div
            ref={leftRef}
            className={`relative transition-all duration-800 ${
              leftVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"
            }`}
          >
            {/* Main image */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-[oklch(0.22_0.10_18/0.2)]">
              <img
                src={GALLERY_IMG}
                alt="Nail art de alta qualidade — Camy Serra"
                className="w-full h-[500px] object-cover"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.22_0.10_18/0.4)] to-transparent" />
            </div>

            {/* Floating badge — 8 anos */}
            <div className="absolute -bottom-6 -right-6 bg-[oklch(0.42_0.18_18)] rounded-2xl p-5 shadow-xl shadow-[oklch(0.42_0.18_18/0.3)] text-center min-w-[120px]">
              <div className="font-display text-4xl font-bold text-white leading-none">8</div>
              <div className="font-body text-white/80 text-xs mt-1 leading-tight">anos de<br />experiência</div>
            </div>

            {/* Cherry decoration SVG */}
            <div className="absolute -top-6 -left-6 w-24 opacity-70 cherry-float">
              <svg viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                <circle cx="35" cy="85" r="22" fill="#8B1A1A" opacity="0.9"/>
                <circle cx="35" cy="85" r="22" fill="url(#ac1)" opacity="0.9"/>
                <circle cx="75" cy="90" r="20" fill="#A01515" opacity="0.9"/>
                <circle cx="75" cy="90" r="20" fill="url(#ac2)" opacity="0.9"/>
                <path d="M35 63 Q50 30 80 20 Q90 50 75 70" stroke="#2D5016" strokeWidth="3" fill="none" strokeLinecap="round"/>
                <path d="M75 70 Q80 40 95 25" stroke="#2D5016" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
                <ellipse cx="88" cy="22" rx="14" ry="9" fill="#3A6B1A" transform="rotate(-20 88 22)"/>
                <ellipse cx="100" cy="18" rx="12" ry="8" fill="#2D5016" transform="rotate(10 100 18)"/>
                <circle cx="28" cy="78" r="5" fill="white" opacity="0.3"/>
                <circle cx="68" cy="83" r="4" fill="white" opacity="0.3"/>
                <defs>
                  <radialGradient id="ac1" cx="35%" cy="30%" r="60%">
                    <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
                    <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
                  </radialGradient>
                  <radialGradient id="ac2" cx="35%" cy="30%" r="60%">
                    <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
                    <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
                  </radialGradient>
                </defs>
              </svg>
            </div>

            {/* Gold border accent */}
            <div className="absolute top-4 left-4 w-24 h-24 border-2 border-[oklch(0.72_0.10_75)] rounded-2xl opacity-40 pointer-events-none" />
          </div>

          {/* Right — Text content */}
          <div
            ref={rightRef}
            className={`transition-all duration-800 delay-200 ${
              rightVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
            }`}
          >
            <span className="font-script text-[oklch(0.42_0.18_18)] text-xl">sobre nós</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[oklch(0.18_0.04_18)] mt-1 mb-2">
              Arte nas Pontas
              <br />
              <span className="italic font-medium text-[oklch(0.42_0.18_18)]">dos Dedos</span>
            </h2>
            <div className="gold-divider mb-6 ml-0" style={{ margin: "1rem 0" }} />

            <p className="font-body text-[oklch(0.40_0.05_18)] text-base leading-relaxed mb-4">
              Há <strong className="text-[oklch(0.42_0.18_18)]">8 anos</strong>, a Camy Serra transforma unhas em verdadeiras obras de arte. Com uma paixão genuína pela beleza e um olhar apurado para os detalhes, cada atendimento é uma experiência única e personalizada.
            </p>
            <p className="font-body text-[oklch(0.40_0.05_18)] text-base leading-relaxed mb-8">
              No nosso studio, você encontra um ambiente acolhedor, sofisticado e completamente dedicado ao seu bem-estar. Utilizamos apenas produtos de alta qualidade para garantir resultados duradouros e seguros.
            </p>

            {/* Highlights */}
            <ul className="space-y-3 mb-8">
              {highlights.map((item) => (
                <li key={item} className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-[oklch(0.42_0.18_18)] flex-shrink-0" />
                  <span className="font-body text-[oklch(0.35_0.05_18)] text-sm">{item}</span>
                </li>
              ))}
            </ul>

            {/* Signature */}
            <div className="flex items-center gap-4 pt-4 border-t border-[oklch(0.88_0.03_18)]">
              <div className="w-12 h-12 rounded-full bg-[oklch(0.42_0.18_18)] flex items-center justify-center flex-shrink-0">
                <span className="font-display text-white font-bold text-lg">CS</span>
              </div>
              <div>
                <span className="font-script text-[oklch(0.42_0.18_18)] text-2xl block leading-none">
                  Camy Serra
                </span>
                <span className="font-body text-[oklch(0.50_0.05_18)] text-xs tracking-widest uppercase">
                  Nail Designer
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
