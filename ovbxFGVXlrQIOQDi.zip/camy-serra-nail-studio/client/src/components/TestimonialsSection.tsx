/**
 * TestimonialsSection — Camy Serra Nail Studio
 * Design: Carrossel de depoimentos com fundo cereja escuro, estrelas douradas
 * Layout: Cards em carrossel com auto-play e navegação manual
 */
import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Ana Paula Rodrigues",
    role: "Cliente há 5 anos",
    text: "A Camy é simplesmente incrível! Minhas unhas nunca ficaram tão lindas. Ela tem um talento único para nail art e um cuidado especial com cada cliente. Não troco por nada!",
    stars: 5,
    avatar: "AP",
  },
  {
    id: 2,
    name: "Fernanda Costa",
    role: "Cliente há 3 anos",
    text: "Fiz o alongamento em gel para o meu casamento e ficou perfeito! A Camy entendeu exatamente o que eu queria e superou todas as minhas expectativas. Studio impecável!",
    stars: 5,
    avatar: "FC",
  },
  {
    id: 3,
    name: "Juliana Mendes",
    role: "Cliente há 2 anos",
    text: "Ambiente super aconchegante e profissional. A Camy é muito atenciosa e o trabalho dela é de altíssima qualidade. As unhas duram muito mais do que em outros lugares.",
    stars: 5,
    avatar: "JM",
  },
  {
    id: 4,
    name: "Camila Oliveira",
    role: "Cliente há 4 anos",
    text: "Sempre saio do studio me sentindo uma rainha! A Camy tem um dom especial para criar designs únicos. Já indiquei para todas as minhas amigas e todas amaram!",
    stars: 5,
    avatar: "CO",
  },
  {
    id: 5,
    name: "Beatriz Santos",
    role: "Cliente há 1 ano",
    text: "Descobri o studio da Camy há um ano e desde então não vou a mais nenhum outro lugar. Atendimento personalizado, produtos de qualidade e resultado sempre impecável.",
    stars: 5,
    avatar: "BS",
  },
];

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const titleRef = useRef<HTMLDivElement>(null);
  const [titleVisible, setTitleVisible] = useState(false);
  const autoplayRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const el = titleRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setTitleVisible(true); },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const startAutoplay = () => {
    autoplayRef.current = setInterval(() => {
      goNext();
    }, 5000);
  };

  const stopAutoplay = () => {
    if (autoplayRef.current) clearInterval(autoplayRef.current);
  };

  useEffect(() => {
    startAutoplay();
    return () => stopAutoplay();
  }, [current]);

  const goTo = (index: number) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrent(index);
    setTimeout(() => setIsAnimating(false), 400);
  };

  const goPrev = () => {
    stopAutoplay();
    goTo((current - 1 + testimonials.length) % testimonials.length);
  };

  const goNext = () => {
    goTo((current + 1) % testimonials.length);
  };

  const visibleCount = typeof window !== "undefined" && window.innerWidth >= 1024 ? 3 : typeof window !== "undefined" && window.innerWidth >= 640 ? 2 : 1;
  const visibleTestimonials = Array.from({ length: Math.min(visibleCount, testimonials.length) }, (_, i) =>
    testimonials[(current + i) % testimonials.length]
  );

  return (
    <section id="depoimentos" className="py-24 bg-[oklch(0.22_0.10_18)] overflow-hidden">
      <div className="container mx-auto">
        {/* Section Header */}
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span className="font-script text-[oklch(0.72_0.10_75)] text-xl">o que dizem</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mt-1 mb-4">
            Depoimentos
          </h2>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-[oklch(0.72_0.10_75)]" />
            <span className="text-[oklch(0.72_0.10_75)] text-lg">✦</span>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-[oklch(0.72_0.10_75)]" />
          </div>
          <p className="font-body text-white/60 text-base max-w-lg mx-auto">
            A satisfação das nossas clientes é a nossa maior conquista. Veja o que elas têm a dizer.
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className="relative">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {visibleTestimonials.map((testimonial, i) => (
              <div
                key={`${testimonial.id}-${current}`}
                className={`bg-[oklch(0.28_0.10_18)] rounded-2xl p-6 border border-white/10 transition-all duration-500 ${
                  i === 0 ? "opacity-100 translate-x-0" : "opacity-100 translate-x-0"
                }`}
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.stars }).map((_, j) => (
                    <Star key={j} size={14} className="fill-[oklch(0.72_0.10_75)] text-[oklch(0.72_0.10_75)]" />
                  ))}
                </div>

                {/* Quote */}
                <p className="font-body text-white/80 text-sm leading-relaxed mb-6 italic">
                  "{testimonial.text}"
                </p>

                {/* Author */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[oklch(0.42_0.18_18)] flex items-center justify-center flex-shrink-0">
                    <span className="font-display text-white text-xs font-bold">
                      {testimonial.avatar}
                    </span>
                  </div>
                  <div>
                    <p className="font-display text-white text-sm font-semibold">
                      {testimonial.name}
                    </p>
                    <p className="font-body text-white/50 text-xs">
                      {testimonial.role}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-10">
            <button
              onClick={goPrev}
              className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all duration-300"
              aria-label="Anterior"
            >
              <ChevronLeft size={18} />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => { stopAutoplay(); goTo(i); }}
                  className={`transition-all duration-300 rounded-full ${
                    i === current
                      ? "w-6 h-2 bg-[oklch(0.72_0.10_75)]"
                      : "w-2 h-2 bg-white/30 hover:bg-white/60"
                  }`}
                  aria-label={`Depoimento ${i + 1}`}
                />
              ))}
            </div>

            <button
              onClick={() => { stopAutoplay(); goNext(); }}
              className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all duration-300"
              aria-label="Próximo"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
