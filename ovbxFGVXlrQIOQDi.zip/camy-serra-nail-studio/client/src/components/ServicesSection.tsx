/**
 * ServicesSection — Camy Serra Nail Studio
 * Design: Cards elegantes com fundo cereja escuro, detalhes dourados
 * Layout: Grid de 3 colunas com cards de serviços e preços
 */
import { useEffect, useRef, useState } from "react";
import { Sparkles, Gem, Flower2, Star, Heart, Crown } from "lucide-react";

const services = [
  {
    icon: Sparkles,
    name: "Manicure Simples",
    description: "Cutícula, lixamento, hidratação e esmaltação com esmalte comum ou base.",
    price: "R$ 45",
    highlight: false,
  },
  {
    icon: Star,
    name: "Manicure em Gel",
    description: "Esmaltação em gel de longa duração com acabamento impecável e brilho intenso.",
    price: "R$ 80",
    highlight: false,
  },
  {
    icon: Crown,
    name: "Alongamento em Gel",
    description: "Extensão de unhas em gel com formato personalizado, resistente e natural.",
    price: "A partir de R$ 150",
    highlight: true,
  },
  {
    icon: Gem,
    name: "Nail Art",
    description: "Arte exclusiva nas unhas: flores, pedras, glitter, foil e designs personalizados.",
    price: "A partir de R$ 30",
    highlight: false,
  },
  {
    icon: Flower2,
    name: "Pedicure Completa",
    description: "Cutícula, esfoliação, hidratação profunda e esmaltação com cuidado total.",
    price: "R$ 65",
    highlight: false,
  },
  {
    icon: Heart,
    name: "Pacote Noiva",
    description: "Manicure + pedicure + nail art especial para o dia mais importante da sua vida.",
    price: "Sob consulta",
    highlight: false,
  },
];

function ServiceCard({ service, delay }: { service: typeof services[0]; delay: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const Icon = service.icon;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`relative group rounded-2xl p-6 transition-all duration-700 hover:scale-105 hover:shadow-xl ${
        service.highlight
          ? "bg-[oklch(0.22_0.10_18)] text-white shadow-lg shadow-[oklch(0.22_0.10_18/0.3)]"
          : "bg-white border border-[oklch(0.88_0.03_18)] hover:border-[oklch(0.42_0.18_18)/50] hover:shadow-[oklch(0.42_0.18_18/0.1)]"
      } ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {/* Highlight badge */}
      {service.highlight && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="bg-[oklch(0.72_0.10_75)] text-[oklch(0.12_0.06_18)] font-body text-xs font-semibold tracking-widest uppercase px-4 py-1 rounded-full">
            Mais Popular
          </span>
        </div>
      )}

      {/* Icon */}
      <div
        className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
          service.highlight
            ? "bg-[oklch(0.72_0.10_75)/20]"
            : "bg-[oklch(0.92_0.03_18)]"
        }`}
      >
        <Icon
          size={22}
          className={service.highlight ? "text-[oklch(0.72_0.10_75)]" : "text-[oklch(0.42_0.18_18)]"}
        />
      </div>

      {/* Content */}
      <h3
        className={`font-display text-lg font-semibold mb-2 ${
          service.highlight ? "text-white" : "text-[oklch(0.18_0.04_18)]"
        }`}
      >
        {service.name}
      </h3>
      <p
        className={`font-body text-sm leading-relaxed mb-4 ${
          service.highlight ? "text-white/70" : "text-[oklch(0.50_0.05_18)]"
        }`}
      >
        {service.description}
      </p>

      {/* Price */}
      <div
        className={`font-display text-xl font-bold ${
          service.highlight ? "text-[oklch(0.72_0.10_75)]" : "text-[oklch(0.42_0.18_18)]"
        }`}
      >
        {service.price}
      </div>

      {/* Decorative line */}
      <div
        className={`absolute bottom-0 left-6 right-6 h-0.5 rounded-full transition-all duration-300 origin-left scale-x-0 group-hover:scale-x-100 ${
          service.highlight
            ? "bg-[oklch(0.72_0.10_75)]"
            : "bg-[oklch(0.42_0.18_18)]"
        }`}
      />
    </div>
  );
}

export default function ServicesSection() {
  const titleRef = useRef<HTMLDivElement>(null);
  const [titleVisible, setTitleVisible] = useState(false);

  useEffect(() => {
    const el = titleRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setTitleVisible(true); },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="servicos" className="py-24 bg-[oklch(0.96_0.015_18)]">
      <div className="container mx-auto">
        {/* Section Header */}
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span className="font-script text-[oklch(0.42_0.18_18)] text-xl">o que oferecemos</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[oklch(0.18_0.04_18)] mt-1 mb-4">
            Serviços & Preços
          </h2>
          <div className="gold-divider mb-4" />
          <p className="font-body text-[oklch(0.50_0.05_18)] text-base max-w-lg mx-auto">
            Oferecemos uma experiência completa de cuidado com as unhas, com técnicas modernas e produtos de alta qualidade.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <ServiceCard key={service.name} service={service} delay={i * 100} />
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <p className="font-body text-[oklch(0.50_0.05_18)] text-sm mb-4">
            Preços sujeitos a alteração. Entre em contato para mais informações.
          </p>
          <a
            href="https://wa.me/5500000000000?text=Olá%20Camy!%20Gostaria%20de%20saber%20mais%20sobre%20os%20serviços."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[oklch(0.42_0.18_18)] hover:bg-[oklch(0.32_0.14_18)] text-white font-body font-medium px-8 py-4 rounded-full transition-all duration-300 hover:scale-105 shadow-lg"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            Consultar disponibilidade
          </a>
        </div>
      </div>
    </section>
  );
}
