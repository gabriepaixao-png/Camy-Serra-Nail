/**
 * GallerySection — Camy Serra Nail Studio
 * Design: Grid assimétrico com imagens de nail art em cards elegantes
 * Layout: Masonry-style com hover zoom e overlay de categoria
 */
import { useEffect, useRef, useState } from "react";

const galleryItems = [
  {
    id: 1,
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/gallery-1-hfpKFMqpyJKzeBAsUksr9U.webp",
    alt: "Nail art floral vermelho cereja com detalhes dourados",
    category: "Nail Art Floral",
    size: "tall",
  },
  {
    id: 2,
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/gallery-2-GPr2gt2DQntkvGBcxyEMVg.webp",
    alt: "Francesinha vermelha com renda branca",
    category: "Francesinha Luxo",
    size: "normal",
  },
  {
    id: 3,
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/gallery-3-XUwDUPtFXwCDsDXJZtRv95.webp",
    alt: "Ombre borgonha com cristais e folha de ouro",
    category: "Ombré & Cristais",
    size: "tall",
  },
  {
    id: 4,
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/gallery-4-Q6eM5mRN7uSbd2EYyTt4kc.webp",
    alt: "Unhas com cerejinhas e detalhes dourados",
    category: "Cherry Nails",
    size: "normal",
  },
  {
    id: 5,
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663570052869/eTadEYfDvwACZoVTCVxksG/gallery-5-mPujJmiYQ2Mmn9hSpvMAkE.webp",
    alt: "Stiletto vermelho com flores 3D brancas",
    category: "3D Nail Art",
    size: "tall",
  },
];

function GalleryCard({ item, delay }: { item: typeof galleryItems[0]; delay: number }) {
  const [hovered, setHovered] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`relative overflow-hidden rounded-2xl cursor-pointer group transition-all duration-700 ${
        item.size === "tall" ? "row-span-2" : "row-span-1"
      } ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
      style={{ transitionDelay: `${delay}ms` }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <img
        src={item.src}
        alt={item.alt}
        className={`w-full h-full object-cover transition-transform duration-500 ${
          hovered ? "scale-110" : "scale-100"
        } ${item.size === "tall" ? "min-h-[400px]" : "min-h-[200px]"}`}
      />

      {/* Overlay */}
      <div
        className={`absolute inset-0 bg-gradient-to-t from-[oklch(0.12_0.08_18/0.9)] via-[oklch(0.12_0.08_18/0.3)] to-transparent transition-opacity duration-300 ${
          hovered ? "opacity-100" : "opacity-0"
        }`}
      />

      {/* Category badge */}
      <div
        className={`absolute bottom-4 left-4 right-4 transition-all duration-300 ${
          hovered ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
        }`}
      >
        <span className="inline-block bg-[oklch(0.42_0.18_18)] text-white font-body text-xs tracking-widest uppercase px-3 py-1 rounded-full">
          {item.category}
        </span>
      </div>

      {/* Gold border on hover */}
      <div
        className={`absolute inset-0 rounded-2xl border-2 transition-all duration-300 pointer-events-none ${
          hovered ? "border-[oklch(0.72_0.10_75)] opacity-100" : "border-transparent opacity-0"
        }`}
      />
    </div>
  );
}

export default function GallerySection() {
  const titleRef = useRef<HTMLDivElement>(null);
  const [titleVisible, setTitleVisible] = useState(false);

  useEffect(() => {
    const el = titleRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setTitleVisible(true); },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="galeria" className="py-24 bg-[oklch(0.99_0.005_90)]">
      <div className="container mx-auto">
        {/* Section Header */}
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span className="font-script text-[oklch(0.42_0.18_18)] text-xl">nossos trabalhos</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[oklch(0.18_0.04_18)] mt-1 mb-4">
            Galeria de Arte
          </h2>
          <div className="gold-divider mb-4" />
          <p className="font-body text-[oklch(0.50_0.05_18)] text-base max-w-lg mx-auto">
            Cada detalhe é pensado com cuidado. Confira alguns dos nossos trabalhos mais recentes e deixe-se inspirar.
          </p>
        </div>

        {/* Asymmetric Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 auto-rows-[200px]">
          {galleryItems.map((item, i) => (
            <GalleryCard key={item.id} item={item} delay={i * 100} />
          ))}
        </div>

        {/* Instagram CTA */}
        <div className="text-center mt-12">
          <a
            href="https://instagram.com/camyserranails"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 border-2 border-[oklch(0.42_0.18_18)] text-[oklch(0.42_0.18_18)] font-body font-medium px-8 py-3 rounded-full transition-all duration-300 hover:bg-[oklch(0.42_0.18_18)] hover:text-white hover:scale-105"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            Ver mais no Instagram
          </a>
        </div>
      </div>
    </section>
  );
}
