/**
 * Footer — Camy Serra Nail Studio
 * Design: Fundo cereja escuro com logo, links e redes sociais
 */
import { Instagram, Heart } from "lucide-react";

// Cherry SVG inline para evitar fundo branco

const navLinks = [
  { label: "Início", href: "#inicio" },
  { label: "Galeria", href: "#galeria" },
  { label: "Serviços", href: "#servicos" },
  { label: "Depoimentos", href: "#depoimentos" },
  { label: "Contato", href: "#contato" },
];

export default function Footer() {
  const handleClick = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-[oklch(0.15_0.08_18)] text-white">
      <div className="container mx-auto py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <svg viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-10 h-10 opacity-80">
                <circle cx="18" cy="42" r="12" fill="#8B1A1A"/>
                <circle cx="18" cy="42" r="12" fill="url(#fc1)"/>
                <circle cx="38" cy="46" r="11" fill="#A01515"/>
                <circle cx="38" cy="46" r="11" fill="url(#fc2)"/>
                <path d="M18 30 Q28 14 40 10" stroke="#2D5016" strokeWidth="2" fill="none" strokeLinecap="round"/>
                <path d="M38 35 Q44 20 50 12" stroke="#2D5016" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
                <ellipse cx="46" cy="10" rx="8" ry="5" fill="#3A6B1A" transform="rotate(-15 46 10)"/>
                <circle cx="13" cy="37" r="3" fill="white" opacity="0.3"/>
                <circle cx="33" cy="41" r="2.5" fill="white" opacity="0.3"/>
                <defs>
                  <radialGradient id="fc1" cx="35%" cy="30%" r="60%">
                    <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
                    <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
                  </radialGradient>
                  <radialGradient id="fc2" cx="35%" cy="30%" r="60%">
                    <stop offset="0%" stopColor="#C41E3A" stopOpacity="0.8"/>
                    <stop offset="100%" stopColor="#5C0A0A" stopOpacity="0.9"/>
                  </radialGradient>
                </defs>
              </svg>
              <div>
                <span className="font-script text-[oklch(0.72_0.10_75)] text-2xl block leading-none">
                  Camy Serra
                </span>
                <span className="font-body text-white/50 text-[10px] tracking-[0.2em] uppercase">
                  Nail Studio
                </span>
              </div>
            </div>
            <p className="font-body text-white/60 text-sm leading-relaxed">
              8 anos transformando unhas em arte. Especialistas em nail art, alongamentos e cuidados personalizados.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-display text-sm font-semibold text-[oklch(0.72_0.10_75)] tracking-widest uppercase mb-4">
              Navegação
            </h4>
            <ul className="space-y-2">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => { e.preventDefault(); handleClick(link.href); }}
                    className="font-body text-sm text-white/60 hover:text-white transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social & Contact */}
          <div>
            <h4 className="font-display text-sm font-semibold text-[oklch(0.72_0.10_75)] tracking-widest uppercase mb-4">
              Redes Sociais
            </h4>
            <div className="flex gap-3 mb-6">
              <a
                href="https://instagram.com/camyserranails"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-[oklch(0.42_0.18_18)] flex items-center justify-center transition-all duration-300 hover:scale-110"
                aria-label="Instagram"
              >
                <Instagram size={16} />
              </a>
              <a
                href="https://wa.me/5500000000000"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-[oklch(0.42_0.18_18)] flex items-center justify-center transition-all duration-300 hover:scale-110"
                aria-label="WhatsApp"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </a>
            </div>
            <p className="font-body text-white/50 text-xs leading-relaxed">
              Rua das Flores, 123 — Sala 05<br />
              Jardim Primavera, São Paulo — SP<br />
              (11) 99999-9999
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-body text-white/40 text-xs">
            © 2024 Camy Serra Nail Studio. Todos os direitos reservados.
          </p>
          <p className="font-body text-white/40 text-xs flex items-center gap-1">
            Feito com <Heart size={10} className="fill-[oklch(0.42_0.18_18)] text-[oklch(0.42_0.18_18)]" /> para unhas lindas
          </p>
        </div>
      </div>
    </footer>
  );
}
