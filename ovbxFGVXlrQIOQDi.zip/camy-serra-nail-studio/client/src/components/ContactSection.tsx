/**
 * ContactSection — Camy Serra Nail Studio
 * Design: Seção de contato com endereço, WhatsApp, Instagram e horários
 * Layout: Duas colunas — info à esquerda, mapa/horários à direita
 */
import { useEffect, useRef, useState } from "react";
import { MapPin, Phone, Instagram, Clock, MessageCircle } from "lucide-react";

const WHATSAPP_NUMBER = "5500000000000";
const WHATSAPP_MSG = "Olá%20Camy!%20Gostaria%20de%20agendar%20um%20horário.";
const INSTAGRAM_URL = "https://instagram.com/camyserranails";

const scheduleItems = [
  { day: "Segunda a Sexta", hours: "9h às 19h" },
  { day: "Sábado", hours: "9h às 17h" },
  { day: "Domingo", hours: "Fechado" },
];

export default function ContactSection() {
  const titleRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [titleVisible, setTitleVisible] = useState(false);
  const [contentVisible, setContentVisible] = useState(false);

  useEffect(() => {
    const observers: IntersectionObserver[] = [];

    const titleEl = titleRef.current;
    if (titleEl) {
      const obs = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) setTitleVisible(true); },
        { threshold: 0.2 }
      );
      obs.observe(titleEl);
      observers.push(obs);
    }

    const contentEl = contentRef.current;
    if (contentEl) {
      const obs = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) setContentVisible(true); },
        { threshold: 0.1 }
      );
      obs.observe(contentEl);
      observers.push(obs);
    }

    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <section id="contato" className="py-24 bg-[oklch(0.99_0.005_90)]">
      <div className="container mx-auto">
        {/* Section Header */}
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span className="font-script text-[oklch(0.42_0.18_18)] text-xl">nos encontre</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[oklch(0.18_0.04_18)] mt-1 mb-4">
            Contato & Localização
          </h2>
          <div className="gold-divider mb-4" />
          <p className="font-body text-[oklch(0.50_0.05_18)] text-base max-w-lg mx-auto">
            Estamos prontas para te receber! Agende seu horário pelo WhatsApp ou venha nos visitar.
          </p>
        </div>

        {/* Content Grid */}
        <div
          ref={contentRef}
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-start transition-all duration-700 ${
            contentVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          {/* Left — Contact Info */}
          <div className="space-y-8">
            {/* Address */}
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-[oklch(0.92_0.03_18)] flex items-center justify-center flex-shrink-0">
                <MapPin size={20} className="text-[oklch(0.42_0.18_18)]" />
              </div>
              <div>
                <h3 className="font-display text-lg font-semibold text-[oklch(0.18_0.04_18)] mb-1">
                  Endereço
                </h3>
                <p className="font-body text-[oklch(0.50_0.05_18)] text-sm leading-relaxed">
                  Rua das Flores, 123 — Sala 05<br />
                  Bairro Jardim Primavera<br />
                  São Paulo — SP, 01234-567
                </p>
              </div>
            </div>

            {/* WhatsApp */}
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-[oklch(0.92_0.03_18)] flex items-center justify-center flex-shrink-0">
                <Phone size={20} className="text-[oklch(0.42_0.18_18)]" />
              </div>
              <div>
                <h3 className="font-display text-lg font-semibold text-[oklch(0.18_0.04_18)] mb-1">
                  WhatsApp
                </h3>
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-body text-[oklch(0.42_0.18_18)] text-sm hover:underline"
                >
                  (11) 99999-9999
                </a>
                <p className="font-body text-[oklch(0.50_0.05_18)] text-xs mt-1">
                  Atendimento rápido e agendamento online
                </p>
              </div>
            </div>

            {/* Instagram */}
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-[oklch(0.92_0.03_18)] flex items-center justify-center flex-shrink-0">
                <Instagram size={20} className="text-[oklch(0.42_0.18_18)]" />
              </div>
              <div>
                <h3 className="font-display text-lg font-semibold text-[oklch(0.18_0.04_18)] mb-1">
                  Instagram
                </h3>
                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-body text-[oklch(0.42_0.18_18)] text-sm hover:underline"
                >
                  @camyserranails
                </a>
                <p className="font-body text-[oklch(0.50_0.05_18)] text-xs mt-1">
                  Acompanhe nossos trabalhos e novidades
                </p>
              </div>
            </div>

            {/* Schedule */}
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-[oklch(0.92_0.03_18)] flex items-center justify-center flex-shrink-0">
                <Clock size={20} className="text-[oklch(0.42_0.18_18)]" />
              </div>
              <div className="flex-1">
                <h3 className="font-display text-lg font-semibold text-[oklch(0.18_0.04_18)] mb-3">
                  Horário de Funcionamento
                </h3>
                <div className="space-y-2">
                  {scheduleItems.map((item) => (
                    <div
                      key={item.day}
                      className="flex justify-between items-center py-2 border-b border-[oklch(0.88_0.03_18)] last:border-0"
                    >
                      <span className="font-body text-sm text-[oklch(0.35_0.05_18)]">{item.day}</span>
                      <span
                        className={`font-body text-sm font-medium ${
                          item.hours === "Fechado"
                            ? "text-[oklch(0.60_0.05_18)]"
                            : "text-[oklch(0.42_0.18_18)]"
                        }`}
                      >
                        {item.hours}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right — CTA Card + Map placeholder */}
          <div className="space-y-6">
            {/* Big WhatsApp CTA */}
            <div className="bg-[oklch(0.22_0.10_18)] rounded-2xl p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-[oklch(0.42_0.18_18)/30] flex items-center justify-center mx-auto mb-4">
                <MessageCircle size={28} className="text-[oklch(0.72_0.10_75)]" />
              </div>
              <h3 className="font-display text-2xl font-bold text-white mb-2">
                Agende seu Horário
              </h3>
              <p className="font-body text-white/60 text-sm mb-6">
                Clique abaixo para falar diretamente com a Camy pelo WhatsApp e garantir seu horário.
              </p>
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`}
                target="_blank"
                rel="noopener noreferrer"
                className="whatsapp-pulse inline-flex items-center gap-3 bg-[oklch(0.42_0.18_18)] hover:bg-[oklch(0.52_0.20_18)] text-white font-body font-semibold px-8 py-4 rounded-full transition-all duration-300 hover:scale-105 shadow-lg w-full justify-center"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                Falar no WhatsApp
              </a>
            </div>

            {/* Instagram Card */}
            <div className="bg-gradient-to-br from-[oklch(0.42_0.18_18)] to-[oklch(0.22_0.10_18)] rounded-2xl p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                <Instagram size={22} className="text-white" />
              </div>
              <div className="flex-1">
                <p className="font-display text-white font-semibold">Siga no Instagram</p>
                <p className="font-body text-white/70 text-xs">Novidades, promoções e inspirações diárias</p>
              </div>
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="font-body text-xs text-white bg-white/20 hover:bg-white/30 px-4 py-2 rounded-full transition-colors duration-300 flex-shrink-0"
              >
                Seguir
              </a>
            </div>

            {/* Map placeholder */}
            <div className="rounded-2xl overflow-hidden border border-[oklch(0.88_0.03_18)] h-48 bg-[oklch(0.96_0.015_18)] flex flex-col items-center justify-center gap-2">
              <MapPin size={28} className="text-[oklch(0.42_0.18_18)]" />
              <p className="font-body text-sm text-[oklch(0.50_0.05_18)] text-center px-4">
                Rua das Flores, 123 — Jardim Primavera<br />
                São Paulo — SP
              </p>
              <a
                href="https://maps.google.com/?q=Rua+das+Flores+123+São+Paulo"
                target="_blank"
                rel="noopener noreferrer"
                className="font-body text-xs text-[oklch(0.42_0.18_18)] hover:underline"
              >
                Ver no Google Maps →
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
