# Ideias de Design — Camy Serra Nail Studio

## Contexto
Site para studio de nail designer com tema de cerejas, cores vermelho cereja e branco, estilo sofisticado, feminino e profissional.

---

<response>
<idea>
**Design Movement:** Art Nouveau Japonês — Sakura meets Cherry Blossom Luxury

**Core Principles:**
- Elegância através da assimetria: layouts inclinados, elementos que "flutuam" na página
- Contraste dramático entre vermelho cereja profundo e branco puro com toques dourados
- Ornamentação delicada: bordas finas, padrões florais sutis em segundo plano
- Hierarquia visual clara com tipografia contrastante (serif elegante + sans-serif leve)

**Color Philosophy:**
- Vermelho cereja profundo (#8B1A1A / oklch equivalente) como cor dominante de impacto
- Branco creme (#FDFAF6) como base respira e dá leveza
- Dourado champagne como acento de luxo nos detalhes
- Rosa pálido como transição suave entre seções

**Layout Paradigm:**
- Hero assimétrico com texto à esquerda e imagem à direita em ângulo diagonal
- Seções alternadas com fundo branco e fundo cereja escuro
- Galeria em mosaico irregular (não grid uniforme)
- Cards de serviços com bordas finas douradas

**Signature Elements:**
- Silhuetas de cerejas como divisores de seção
- Linha fina dourada como elemento decorativo recorrente
- Padrão de pontos delicados em segundo plano nas seções escuras

**Interaction Philosophy:**
- Hover suave com transição de cor e elevação de sombra
- Scroll reveal com fade-in elegante
- Botão de WhatsApp com pulso suave

**Animation:**
- Fade-in com leve translação vertical (20px → 0) ao entrar na viewport
- Hover nos cards: elevação de 4px com sombra expandida
- Transições de 400ms com easing cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Typography System:**
- Display: Playfair Display (serif elegante para títulos)
- Body: Lato (sans-serif limpo para texto corrido)
- Accent: Cormorant Garamond Italic para frases de destaque
</idea>
<probability>0.08</probability>
</response>

<response>
<idea>
**Design Movement:** Parisian Boudoir Luxe — Vermelho, Branco e Ouro

**Core Principles:**
- Simetria clássica com detalhes ornamentais discretos
- Fundo branco dominante com acentos em vermelho cereja vibrante
- Tipografia serifada como elemento principal de identidade
- Espaçamento generoso que transmite exclusividade

**Color Philosophy:**
- Branco puro como base dominante (limpeza, sofisticação)
- Vermelho cereja (#9B1C1C) para CTAs, destaques e bordas
- Ouro suave (#C9A84C) para ornamentos e divisores
- Cinza quase branco para fundos de seção alternados

**Layout Paradigm:**
- Coluna central larga com margens generosas
- Seções com separadores ornamentais dourados
- Grid de 3 colunas para serviços com cards elevados
- Galeria em masonry com molduras finas

**Signature Elements:**
- Ornamentos tipográficos (floreados) nos títulos de seção
- Linha dupla fina como separador de conteúdo
- Ícone de cereja estilizado como favicon e marca d'água

**Interaction Philosophy:**
- Elegância discreta: sem animações excessivas
- Hover com mudança de cor suave
- Scroll suave entre seções

**Animation:**
- Fade-in simples ao entrar na viewport
- Hover nos botões: preenchimento de cor da borda para dentro
- Transições de 300ms com ease-in-out

**Typography System:**
- Display: Cormorant Garamond (serif clássico)
- Body: Raleway (sans-serif geométrico elegante)
- Accent: Cormorant Garamond Italic
</idea>
<probability>0.07</probability>
</response>

<response>
<idea>
**Design Movement:** Modern Feminine Luxury — Editorial de Moda com Cerejas

**Core Principles:**
- Contraste dramático: fundo escuro cereja com texto branco no hero, invertendo nas demais seções
- Tipografia grande e ousada como elemento visual principal
- Fotografia em destaque com tratamento editorial
- Microanimações que reforçam o caráter artesanal e artístico

**Color Philosophy:**
- Vermelho cereja escuro (#6B0F1A) como cor do hero e seções de impacto
- Branco puro para seções de conteúdo
- Rosa cereja claro (#F8E8E8) para fundos de seções alternadas
- Dourado (#D4AF37) para detalhes e ícones

**Layout Paradigm:**
- Hero full-screen com texto centralizado e imagem em overlay
- Seções em largura total com padding generoso
- Galeria em grid assimétrico 2+1 e 1+2 alternados
- Depoimentos em carrossel horizontal

**Signature Elements:**
- Padrão de cerejas ilustradas como elemento decorativo de fundo
- Número "8" estilizado na seção de destaque
- Gradiente sutil de vermelho para rosa nas bordas das imagens

**Interaction Philosophy:**
- Parallax suave no hero
- Cards da galeria com zoom suave no hover
- Botão de agendamento com animação de pulso

**Animation:**
- Parallax no hero: 0.3x da velocidade de scroll
- Scroll reveal: slide-up 30px + fade, 500ms, stagger de 100ms entre elementos
- Hover na galeria: scale(1.03) + sombra expandida, 300ms
- Pulse no botão WhatsApp: animação de anel expandindo

**Typography System:**
- Display: Playfair Display Bold para títulos principais
- Body: DM Sans para texto corrido
- Script: Dancing Script para elementos decorativos e assinatura
</idea>
<probability>0.09</probability>
</response>

---

## Design Escolhido: Modern Feminine Luxury (Opção 3)

Escolhida por combinar o impacto visual do vermelho cereja escuro com a elegância editorial, criando uma experiência que transmite luxo, profissionalismo e feminilidade. A tipografia grande e ousada com Playfair Display garante presença de marca forte, enquanto o DM Sans mantém a legibilidade. As microanimações reforçam o caráter artístico do trabalho de nail design.
